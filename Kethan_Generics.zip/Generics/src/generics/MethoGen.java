package generics;

import java.util.Arrays;
import java.util.List;

import generics.res.GenericClass;

class res {

	static public abstract class GenericClass<E> { //abstarct class

		public abstract boolean cal(E x);

	}

	

}
 class Prime extends GenericClass<Integer> { //extending abstarct and implemetation(prime number)
	@Override
	public boolean cal(Integer t) {
		for (int i = 2; i < t; ++i) {
			if (t % i == 0) {
				return false;
			}
		}
		return true;
	}

	

}
 
 class Even extends GenericClass<Integer> {//extending abstarct and implemetation(Even number)
	@Override
	public boolean cal(Integer t) {
		return (t % 2 == 0);
	}
	

}
class calulate{
	public <T> int count(List<T> list, GenericClass<T> s) {
		int count1 = 0;

		for (T type : list) {
			if (s.cal(type) ) {
				++count1;
			}
			
		}
		return count1;
	}
}

public class MethoGen {

	
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, 4, 5, 7, 8, 9, 13, 11,33,44);
		Prime p = new Prime();
		Even e = new Even();
		calulate cc = new calulate();
		System.out.println("Prime: "+cc.count(list, p));
		System.out.println("Even: "+cc.count(list, e));
		
	}

}
