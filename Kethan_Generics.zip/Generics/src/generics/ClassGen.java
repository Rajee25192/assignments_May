package generics;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

class Media { //Dummy class Media
	String Name ;
	String type;
	Media(String Name, String type){
		this.Name=Name;
		this.type=type;
	}
}



class library<E extends Media>{  //Generic class that extends media class
	
	List<E> res = new ArrayList<>(); //storage
	public void add(E e) { //add into arraylist
		res.add(e);
	}
	public void print() { //display
		System.out.println("generic class:");
		for(E i : res) {
			
			System.out.println("Name: "+ i.Name);
			System.out.println("Type:" + i.type+ "\n");
			
		}
	}
}



class Lib{ //non generic class
	@SuppressWarnings("rawtypes")
	List lb= new ArrayList(); //arraylist non generic
	
	@SuppressWarnings("unchecked")
	public void add(Media m) { //add media instace
		lb.add(m);
	}
	
	public void print() { //display
		@SuppressWarnings("rawtypes")
		ListIterator i = lb.listIterator(); //iterator
		System.out.println("Non generic class:");
		while(i.hasNext())
		{
		    Media a = (Media) i.next(); //casting
			System.out.println("Name: "+ a.Name);
			System.out.println("Type:" + a.type+ "\n");
		}
	}
	
}

public class ClassGen {

	public static void main(String[] args) {
		library<Media> lib = new library<Media>();
		Media c = new Media("The witcher","Book");
		lib.add(c);
		lib.print();
		
		Lib l = new Lib();
		l.add(c);
		l.print();
	}

}
