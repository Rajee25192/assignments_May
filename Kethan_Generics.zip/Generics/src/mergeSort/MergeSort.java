package mergeSort;


public class MergeSort<E extends Comparable<E>> {

	private E[] mergeSortG(E[] inpArr, E[] tempArr,int begin, int end) 
	  {
	 int mid = (begin + end) /2;
	 if(begin == end) {
	         return inpArr;    
	 }
	  
	 mergeSortG(inpArr,tempArr,begin,mid);
	 mergeSortG(inpArr,tempArr,mid+1,end);
	 mergeG(inpArr,tempArr,begin,mid,end);
	return inpArr;
	     
	 
	   }
	  
	   private void mergeG(E[] inpArr, E[] tempArr,int begin, int mid, int end) {
	 for(int i = begin; i <= end; i++) {
	         tempArr[i] = inpArr[i];
	 }
	   
	 int left = begin;
	 int right = mid+1;
	   
	 for(int current = begin; current <= end; current++) {
	     if(left == mid+1) {
	  inpArr[current] = tempArr[right++];
	     } else if(right > end) {
	  inpArr[current] = tempArr[left++];
	     } else if(tempArr[left].compareTo(tempArr[right]) < 0){
	  inpArr[current] = tempArr[left++];
	     } else {
	  inpArr[current] = tempArr[right++];
	     }
	 }
	   
	   } 
	
	public static void main(String[] args) {
		Integer[] number = {15,7,43,6,6,2,2,8,9,454,32};
		Integer[] tmp = new Integer[number.length] ;
		MergeSort<Integer> m = new MergeSort<>();
		Integer[]z = m.mergeSortG(number,tmp,0,number.length-1);
		
		for(Integer a: z) {
			System.out.print(a+ " ");
		}
		
		
		Character[] ch = {'v','h','a','y','i','u'};
		Character[] tmp1 = new Character[ch.length] ;
		MergeSort<Character> m1 = new MergeSort<>();
		Character[] z1 = m1.mergeSortG(ch,tmp1,0,ch.length-1);
		System.out.println();
		for(Character a: z1) {
			System.out.print(a+ " ");
		}
	}

}
