package stack;

import java.util.EmptyStackException;

interface stInf<T>{ //stack interface
	void push(T number);
	T pop();
	boolean isEmpty();
}


class stImp <T> implements stInf<T>{ //stack implementation
	
	int size ;
	 Object[] array;
	 int top;
	
	stImp(int size){ //constructor
		this.size=size;
		this.array = new Object[size];
		this.top=-1;
	}
	@Override
	public boolean isEmpty() { //if no values present
		
		return top == -1;
	}
	
	public boolean isFull() { //check is full
        return top == size-1; 
    }
	
	@Override
	public void push(T number) { //push operation
		// TODO Auto-generated method stub
		System.out.println("Pushing: "+number);
		if(!this.isFull()) {
            ++top;
            array[top] = number;
        }
        else {
           throw new StackOverflowError(); //will throw overflow error if full
        }
	}

	@Override 
	public T pop() { //pop operation, only move to previous place does not delete space
		// TODO Auto-generated method stub

		if(this.isEmpty()) {
			throw new EmptyStackException();
		}
		top--;
		System.out.println("Poping: "+ array[top+1]);
		return element(top+1);
	}
	@SuppressWarnings("unchecked")
	private T element(int index) {
        return (T)array[index];
    }
	
}

public class Stack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 stImp<Integer> s = new stImp<Integer>(3);
		 
		 s.push(3);
		 s.push(5);
		 s.pop();
		 System.out.println("is Empty: "+s.isEmpty());
	}

}
