package binarySearch;

class BinarySearcher<T extends Comparable<T>> {
    private T[] a;

    public BinarySearcher(T[] words) {
        a = words;
    }

    public int search(Comparable<T> v) {
    	System.out.print("Element : "+ v +" ");
        int low = 0;
        int high = a.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            T midVal = a[mid];
            int result = v.compareTo(midVal);

            if (result < 0) {
                high = mid - 1;
            }

            else if (result > 0) {
                low = mid + 1;
            } 

            else {
                return mid;
            }
        }

        return -1;
    }
}


public class Binary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] words = {"a","b","c","d"};
		BinarySearcher<String> br = new BinarySearcher<String>(words);
		System.out.println("At Position : "+ br.search("c"));
		
		Integer[] number = {3,4,5,6,6,7,9};
		BinarySearcher<Integer> nm = new BinarySearcher<>(number);
		System.out.println("At Position : "+ nm.search(4));
	}

}
