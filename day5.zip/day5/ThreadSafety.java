package com.practice.java.day5;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ThreadSafety {
	public static void main(String args[]) {
		ReentrantReadWriteLockCounter rWriteLockCounter = new ReentrantReadWriteLockCounter();
		Hall1 hall1 = new Hall1(rWriteLockCounter);
		Hall2 hall2 = new Hall2(rWriteLockCounter);
		hall1.start();
		hall2.start();
	}
}

class ReentrantReadWriteLockCounter {

	private int counter;
	private final ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();
	private final Lock readLock = rwLock.readLock();
	private final Lock writeLock = rwLock.writeLock();

	public ReentrantReadWriteLockCounter() {
		this.counter = 0;
	}

	public void incrementCounter() {
		writeLock.lock();
		try {
			counter += 1;
			System.out.println("No. of persons in the hall: " + counter);
		} finally {
			writeLock.unlock();
		}
	}

	public int getCounter() {
		readLock.lock();
		try {
			return counter;
		} finally {
			readLock.unlock();
		}
	}
}

class Hall1 extends Thread {
	ReentrantReadWriteLockCounter rCounter;

	Hall1(ReentrantReadWriteLockCounter rCounter) {
		this.rCounter = rCounter;
	}

	public void run() {
		rCounter.incrementCounter();
	}

}

class Hall2 extends Thread {
	ReentrantReadWriteLockCounter rCounter;

	Hall2(ReentrantReadWriteLockCounter rCounter) {
		this.rCounter = rCounter;
	}

	public void run() {
		rCounter.incrementCounter();
	}
}

/*
 * References: https://www.baeldung.com/java-thread-safety
 */