package com.practice.java.day5;

public class WithoutThreadSafety {
	public static void main(String args[]) {

		Counter c = new Counter();
		Thread1 thread1 = new Thread1(c);
		Thread2 thread2 = new Thread2(c);
		thread1.start();
		thread2.start();
	}
}

class Counter {

	private int counter;

	public Counter() {
		this.counter = 0;
	}

	public void incrementCounter() {
		counter += 1;
		System.out.println("Count: " + counter);
	}

	public int getCounter() {
		return counter;
	}
}

class Thread1 extends Thread {
	Counter counter;

	Thread1(Counter counter) {
		this.counter = counter;
	}

	public void run() {
		counter.incrementCounter();
	}

}

class Thread2 extends Thread {
	Counter counter;

	Thread2(Counter counter) {
		this.counter = counter;
	}

	public void run() {
		counter.incrementCounter();
	}

}