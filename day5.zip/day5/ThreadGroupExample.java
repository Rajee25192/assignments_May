package com.practice.java.day5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class ThreadGroupExample {
	public static void main(String[] args) {
		ThreadGroupExample tge = new ThreadGroupExample();

		ThreadGroup readingThreads = new ThreadGroup("ReadingThreadGroup");

		RWFile rw = new RWFile();

		for (int i = 1; i <= 2; i++) {
			A thread = tge.new A(readingThreads, "Thread-" + i, rw);
			thread.start();
		}

		ThreadGroup writingThreads = new ThreadGroup("WritingThreadGroup");

		for (int i = 3; i <= 4; i++) {
			B thread = tge.new B(writingThreads, "Thread-" + i, rw);
			thread.start();
		}

	}

	class A extends Thread {
		RWFile r;

		A(ThreadGroup tg, String name, RWFile r) {
			super(tg, name);
			this.r = r;
		}

		public void run() {
			r.copyContents();
			System.out.println("R/W file contents by " + Thread.currentThread().getName() + " from "
					+ Thread.currentThread().getThreadGroup().getName());
		}
	}

	class B extends Thread {
		RWFile r;

		B(ThreadGroup tg, String name, RWFile r) {
			super(tg, name);
			this.r = r;
		}

		public void run() {
			r.sendContentsToDB();
			System.out.println("File contents written to database by " + Thread.currentThread().getName() + " from "
					+ Thread.currentThread().getThreadGroup().getName());
		}
	}
}

class RWFile {

	public synchronized void copyContents() {
		Scanner sc = new Scanner(System.in);
		System.out.println("File to be copied: ");
		String fileName = sc.nextLine();

		FileInputStream instream = null;
		FileOutputStream outstream = null;

		try {
			File infile = new File("C:\\Users" + fileName);
			File outfile = new File("C:\\Users\\copiedContents.txt");

			instream = new FileInputStream(infile);
			outstream = new FileOutputStream(outfile);

			byte[] buffer = new byte[1024];

			int length;

			while ((length = instream.read(buffer)) > 0) {
				outstream.write(buffer, 0, length);
			}

			instream.close();
			outstream.close();

			System.out.println("File copied successfully.");

		} catch (FileNotFoundException fe) {
			System.out.println("File Not Found.");
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

	}

	public synchronized void sendContentsToDB() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d4", "root", "pwd");

			Scanner input = new Scanner(System.in);

			System.out.println("Enter file name to store in database: ");
			String fname = input.nextLine();

			String filePath = "C:\\Users" + fname;
			InputStream inputStream = new FileInputStream(new File(filePath));

			String sql = "insert into attachment (FILE_NAME, FILE_DATA) values (?, ?)";
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setString(1, fname);
			statement.setBlob(2, inputStream);
			statement.executeUpdate();

			statement.close();

			/*
			 * String sql = "SELECT FILE_DATA  FROM attachment where file_name = 'a.txt'";
			 * PreparedStatement stmt = con.prepareStatement(sql); ResultSet resultSet =
			 * stmt.executeQuery(); while (resultSet.next()) {
			 * 
			 * java.sql.Blob blob = resultSet.getBlob("FILE_DATA");
			 * 
			 * InputStream inputStream = blob.getBinaryStream(); OutputStream outputStream =
			 * new FileOutputStream(
			 * "C:\\Users\\MV\\Desktop\\M\\IMCS Group\\Assignments\\backend\\files\\x.txt");
			 * 
			 * int bytesRead = -1; byte[] buffer = new byte[4096]; while ((bytesRead =
			 * inputStream.read(buffer)) != -1) { outputStream.write(buffer, 0, bytesRead);
			 * }
			 * 
			 * inputStream.close(); outputStream.close(); }
			 */

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}

/*
 * References:
 * https://java.meritcampus.com/core-java-topics/java-thread-groups-and-
 * threadgroup-class-in-java
 * https://beginnersbook.com/2014/05/how-to-copy-a-file-to-another-file-in-java/
 * https://o7planning.org/en/10839/uploading-and-downloading-files-from-database
 * -using-java-servlet
 * https://www.codejava.net/java-se/jdbc/insert-file-data-into-mysql-database-
 * using-jdbc
 * https://www.codejava.net/java-se/jdbc/read-file-data-from-database-using-jdbc
 */
