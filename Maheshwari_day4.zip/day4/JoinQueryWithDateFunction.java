package com.practice.java.day4;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class JoinQueryWithDateFunction {

	public static void main(String args[]) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d4", "root", "pwd");

			/*
			 * java.sql.Date sqlDate = new java.sql.Date(date.getTime()); java.sql.Timestamp
			 * sqlTime = new java.sql.Timestamp(date.getTime()); PreparedStatement ps =
			 * con.prepareStatement("insert into job (date,time) values(?,?)");
			 * ps.setDate(1, sqlDate); ps.setTimestamp(2, sqlTime); ps.executeUpdate();
			 * ps.close();
			 */

			/*
			 * java.util.Date date = new java.util.Date(); java.sql.Date sqlDate = new
			 * java.sql.Date(date.getTime()); java.sql.Timestamp sqlTime = new
			 * java.sql.Timestamp(date.getTime());
			 *
			 * String sql = "update job " + "set time = '" + sqlTime + "', date = '" +
			 * sqlDate + "' where id in (1)"; stmt.executeUpdate(sql);
			 */

			Statement stmt = con.createStatement();
			String query = "SELECT name, date, time from emp inner join job on emp.id = job.id";
			ResultSet rs = stmt.executeQuery(query);
			System.out.println("Name  Date   Time");

			while (rs.next()) {
				String name = rs.getString("name");
				Date date = rs.getDate("date");
				Timestamp time = rs.getTimestamp("time");
				System.out.println(name + "  " + date + "   " + time);
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}

/*
 * References: https://www.tutorialspoint.com/mysql/mysql-data-types.htm
 * https://www.thecrazyprogrammer.com/2016/02/how-to-insert-date-and-time-in-
 * mysql-using-java.html
 * https://www.tutorialspoint.com/jdbc/jdbc-update-records.htm
 * https://www.tutorialspoint.com/javaexamples/jdbc_innerjoin.htm
 */