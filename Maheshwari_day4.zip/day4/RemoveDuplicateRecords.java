package com.practice.java.day4;

import java.sql.*;

public class RemoveDuplicateRecords {

	public static void main(String args[]) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d4", "root", "pwd");

			Statement stmt = con.createStatement();

			String sql = "delete from emp where id in(select id from (select id, row_number() over (partition by name order by name) as row_num from emp) t where row_num > 1)";
			stmt.executeUpdate(sql);

			ResultSet rs = stmt.executeQuery("select * from emp");
			while (rs.next())
				System.out.println(rs.getString(1) + "  " + rs.getInt(2) + "  " + rs.getInt(3));
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}

/*
 * References: https://www.tutorialspoint.com/jdbc/jdbc-delete-records.htm
 * https://www.mysqltutorial.org/mysql-delete-duplicate-rows/
 * https://stackoverflow.com/questions/11448068/mysql-error-code-1175-during-
 * update-in-mysql-workbench
 */