package com.practice.java.day4;

import java.sql.*;
import java.util.Scanner;

public class MySQLConnection {

	public static void main(String args[]) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d4", "root", "pwd");

			Scanner input = new Scanner(System.in);

			System.out.println("Enter name: ");
			String name = input.nextLine();

			System.out.println("Enter age: ");
			int age = input.nextInt();

			Statement stmt = con.createStatement();

			// insert the data
			stmt.executeUpdate("insert into emp (name, age)" + "values ('" + name + "'," + age + ")");

			ResultSet rs = stmt.executeQuery("select * from emp");
			while (rs.next())
				System.out.println(rs.getString(1) + "  " + rs.getInt(2) + "  " + rs.getInt(3));
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}

/*
 * References:
 * https://www.javatpoint.com/example-to-connect-to-the-mysql-database
 * https://www.tutorialspoint.com/mysql/mysql-insert-query.htm
 * https://alvinalexander.com/java/edu/pj/jdbc/jdbc0002/
 * https://www.w3schools.com/SQl/sql_autoincrement.asp
 * https://www.w3schools.com/java/java_user_input.asp
 * https://www.hostingadvice.com/how-to/mysql-alter-table/
 */
