package com.practice.java.day6;

import java.util.Arrays;
import java.util.Collection;
import java.util.function.Predicate;

public class GenericMethodToCountElements {

	public static void main(String[] args) {
		System.out.println("Counting odd numbers ");
		Collection<Integer> ci = Arrays.asList(1, 2, 3, 4);
		long count = Algorithm.countIf(ci, CountPredicate::checkOddNumber);
		System.out.println("Number of odd integers = " + count);

		System.out.println("Counting prime numbers ");
		Collection<Integer> cPrime = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 13);
		long countPrime = Algorithm.countIf(cPrime, CountPredicate::checkPrimeNumber);
		System.out.println("Number of prime numbers = " + countPrime);

		System.out.println("Counting palindromes ");
		Collection<String> cPalindrome = Arrays.asList("madam", "amoreroma", "tacocat", "hello");
		long countPalindrome = Algorithm.countIf(cPalindrome, CountPredicate::checkPalindrome);
		System.out.println("Number of palindrome = " + countPalindrome);
	}
}

class CountPredicate {
	public static boolean checkOddNumber(final int num) {
		return num % 2 != 0;
	}

	public static boolean checkPrimeNumber(final int num) {
		if (num == 0 || num == 1) {
			return false;
		}

		for (int i = 2; i * i <= num; i++) {
			if (num % i == 0) {
				return false;
			}
		}
		return true;
	}

	public static boolean checkPalindrome(final String word) {
		for (int i = 0; i < word.length() / 2; i++) {
			if (word.charAt(i) != word.charAt(word.length() - 1 - i)) {
				return false;
			}
		}
		return true;
	}
}

final class Algorithm {
	public static <T> long countIf(Collection<T> collection, Predicate<T> predicate) {
		return collection.stream().filter(predicate).count();
	}
}

/*
 * References:
 * https://codereview.stackexchange.com/questions/163622/count-elements-in-a-
 * collection-based-on-a-condition-java-8
 * https://www.geeksforgeeks.org/double-colon-operator-in-java/
 */