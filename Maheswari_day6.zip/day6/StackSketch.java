package com.practice.java.day6;

import java.util.Stack;

public class StackSketch {
	public static void main(String[] args) {

		Stack<String> stack = new Stack<String>();

		push_stack​(stack);
		System.out.println(stack.peek());

		String topElement = pop_stack(stack);
		System.out.println(topElement);

		boolean stackEmpty = empty(stack);
		System.out.println(stackEmpty);

		System.out.println(stack);

	}

	public static String push_stack​(Stack<String> item) {
		return item.push("5");
	}

	public static String pop_stack(Stack<String> item) {
		return item.pop();
	}

	public static boolean empty(Stack<String> stack) {
		if (stack.isEmpty()) {
			return true;
		}
		return false;
	}
}

/*
 * References: https://docs.oracle.com/javase/7/docs/api/java/util/Stack.html
 * https://www.geeksforgeeks.org/stack-class-in-java/
 * https://www.journaldev.com/13401/java-stack
 */