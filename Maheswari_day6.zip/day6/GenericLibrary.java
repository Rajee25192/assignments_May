package com.practice.java.day6;

import java.util.ArrayList;
import java.util.List;

public class GenericLibrary {

	public static void main(String[] args) {

		List<Book> bookList = new ArrayList<Book>();
		bookList.add(new Book());

		List<Video> videoList = new ArrayList<Video>();
		videoList.add(new Video());

		List<Newspaper> newspapersList = new ArrayList<Newspaper>();
		newspapersList.add(new Newspaper());

		getMaterialList(bookList);
		getMaterialList(videoList);
		getMaterialList(newspapersList);
		System.out.println();
		System.out.println("If Generics is not used then the material list gets called for each mterial separately: ");
		getBookList(new Book());
		getVideoList(new Video());
		getNewspaperList(new Newspaper());
	}

	public static void getMaterialList(List<? extends Library> lists) {
		for (Library library : lists) {
			library.getMaterialName();
		}
	}

	// If generics is not used, the list has to be called for each material.

	public static void getBookList(Book book) {
		book.getMaterialName();
	}

	public static void getVideoList(Video video) {
		video.getMaterialName();
	}

	public static void getNewspaperList(Newspaper newspaper) {
		newspaper.getMaterialName();
	}

	// ___________________________________________________________________________________________________________
}

abstract class Library {
	abstract void getMaterialName();
}

class Book extends Library {
	@Override
	void getMaterialName() {
		System.out.println("Book");
	}
}

class Video extends Library {
	@Override
	void getMaterialName() {
		System.out.println("Video");
	}
}

class Newspaper extends Library {
	@Override
	void getMaterialName() {
		System.out.println("Newspaper");
	}
}

//Reference: https://www.javatpoint.com/generics-in-java