package com.practice.java.day6;

import java.util.HashMap;
import java.util.Map;

public class DictionarySketch {
	public static void main(String[] args) {

		Map<String, String> map = new HashMap<String, String>();
		put(map);
		String element1 = (String) get(map);
		System.out.println(element1);

		keySet(map);

		boolean mapEmpty = empty(map);
		System.out.println(mapEmpty);

		// get, put, isEmpty, keys, and values
	}

	public static void put(Map<String, String> map) {
		map.put("key1", "element 1");
		map.put("key2", "element 2");
		map.put("key3", "element 3");
	}

	public static String get(Map<String, String> map) {
		String value = (String) map.get("key1");
		return value;
	}

	public static void keySet(Map<String, String> map) {
		for (String key : map.keySet()) {
			String value = map.get(key);
			System.out.println(key + " " + value);
		}
	}

	public static boolean empty(Map<String, String> map) {
		if (map.isEmpty()) {
			return true;
		}
		return false;
	}
}

/*
 * References:
 * https://docs.oracle.com/javase/8/docs/api/java/util/HashMap.html#keySet--
 * http://tutorials.jenkov.com/java-collections/map.html
 */
