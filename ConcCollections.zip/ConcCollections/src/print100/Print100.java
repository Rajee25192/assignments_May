package print100;

public class Print100 {

	static void print(int a) {
		System.out.println(a);
		if (a == 1) {
			return;
		}
		print(a - 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		print(100);
	}

}
