package jpeg;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Jpeg {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Queue que = new LinkedList(); // create a queue
		Path start = Paths.get("D:\\html'\\Ready to use JPGs\\"); // filepath
		System.out.println(start);

		try { // exception check
			Files.walkFileTree(start, new SimpleFileVisitor<Path>() { // usage of file package

				@Override
				public FileVisitResult visitFile(Path filePath, BasicFileAttributes attrs) throws IOException {
					File file = new File(filePath.toString());
					if (filePath.toString().endsWith(".jpg") && (file.length() <= 1048576)) { // check if file is less
																								// than 1MB and ends
																								// with jpgextension
						que.add(filePath); // add to queue
					}
					return FileVisitResult.CONTINUE;
				}
			});
		} catch (IOException e) {
			e.printStackTrace(); // print exception
		}

		System.out.println(que.toString()); // print filepaths

		Iterator<Path> iterator = que.iterator(); // iterator for queue

		while (iterator.hasNext()) {
			Path filePath = iterator.next();
			File file = new File(filePath.toString());

			try {
				Image image = ImageIO.read(file); // uses image class
				JFrame frame = new JFrame(); // jframe class
				frame.setSize(500, 500); // set size of frame
				JLabel label = new JLabel(new ImageIcon(image)); // create a label for the frame
				frame.add(label); // add to frame
				frame.setVisible(true);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}
