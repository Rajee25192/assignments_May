package linkedHash;

import java.util.LinkedHashMap;
import java.util.Random;
import java.util.SortedSet;
import java.util.TreeSet;

public class LinkedHash {

	public static void main(String[] args) {
		Random Random = new Random();
		// HashMap declaration
		LinkedHashMap<String, Integer> map = new LinkedHashMap<>();
		map.put("Array", 22);
		map.put("LinkedList", 33);
		map.put("maps", 65);
		map.put("List", 55);
		map.put("Set", 65);
		map.put("Stack", 65);
		map.put("Stack", 34);

		SortedSet<String> set = new TreeSet<>(map.keySet()); // natural sorted set
		System.out.println("Key set values: " + set.toString());

		set.add("folas");// add to set example

		if (map.keySet().containsAll(set)) { // if contains all map values display
			System.out.println(map.toString());
		} else {
			for (String s : set) { // else check which one and insert with random value
				if (!map.keySet().contains(s)) {
					map.put(s, Random.nextInt(100));
				}
			}
			System.out.println("values in map: " + map.toString()); // display
		}
	}

}
