package sortFiles;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class sortw {

	void path(String in, String type, Date date) { // starts at path

		List<String> doctype = null, collect = null, jpgtype = null, txttype = null;
		Path start = Paths.get("D:\\Program Files (x86)");
		try (Stream<Path> stream = Files.walk(start, 1)) { // find list of all file paths
			collect = stream.map(String::valueOf).collect(Collectors.toList());

		} catch (IOException e) {
			e.printStackTrace();
		}

		try (Stream<Path> stream = Files.walk(start, 1)) { // list with only jpg paths
			jpgtype = stream.map(x -> x.toString()).filter(f -> f.endsWith(".jpg")).collect(Collectors.toList());

		} catch (IOException e) {

			e.printStackTrace();
		}

		try (Stream<Path> stream = Files.walk(start, 1)) { // list with doc type paths
			doctype = stream.map(x -> x.toString()).filter(f -> f.endsWith(".doc")).collect(Collectors.toList());

		} catch (IOException e) {

			e.printStackTrace();
		}

		try (Stream<Path> stream = Files.walk(start, 1)) { // list with txt paths

			txttype = stream.map(x -> x.toString()).filter(f -> f.endsWith(".txt")).collect(Collectors.toList());

		} catch (IOException e) {

			e.printStackTrace();
		}
		determinetype(collect); // function to find file types
		displaybytype(jpgtype, doctype, txttype, type, in, date); // next move to segregate by user file type
																	// preference

	}

	void displaybytype(List<String> jpgtype, List<String> doctype, List<String> txttype, String type, String in,
			Date date) {

		if (type.equals("doc")) { // if else block to filter file selection
			dateMod(doctype, in, date); // move to date segregation
		} else if (type.equals("txt")) {
			dateMod(txttype, in, date);
		} else {
			dateMod(jpgtype, in, date);
		}
	}

	void dateMod(List<String> ls, String in, Date date) {
		List<String> srt = new ArrayList<String>(); // update list after date filter
		@SuppressWarnings("unused")
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		for (String l : ls) {
			Path path = Paths.get(l);
			File file = new File(path.toString());
			Date lm = new Date(file.lastModified()); // find last modified date
			if (lm.before(date)) { // List before users date preference will be added to list
				srt.add(l);
			}

		}
		sort(ls, in); // finally move to sorting
	}

	void sort(List<String> ls, String in) {
		System.out.println("*************displaySorted**************");
		if (in.equals("asc")) {
			Collections.sort(ls); // natural sort or ascending
			ls.forEach(System.out::println);
		} else {
			Collections.sort(ls, Collections.reverseOrder()); // Descending
			ls.forEach(System.out::println);
		}
	}

	void determinetype(List<String> ls) {
		System.out.println("*****count of file types in directory********");
		HashMap<String, Integer> freq = new HashMap<String, Integer>(); // map to maintain count
		String fileType;
		for (String s : ls) {
			try {
				Path path = Paths.get(s);
				fileType = Files.probeContentType(path);
				Integer count = freq.get(fileType);
				if (count == null) { // if filetype not present add it(restricted file types appear as null)
					freq.put(fileType, 1);
				} else {
					freq.put(fileType, count + 1); // increment counter
				}

			} catch (IOException ioException) {
				System.out
						.println("ERROR: Unable to determine file type for " + ls + " due to exception " + ioException);
			}
		}

		System.out.println(freq.toString());// output all map elemnts
	}
}

public class SortFiles {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// INPUT FROM CONSOLE
		System.out.println("Insert asc(Ascending) or des(descending)");
		String sr = sc.nextLine();
		System.out.println("Insert type of file - txt,doc or jpg");
		String type = sc.nextLine();
		System.out.println("Insert date for range(dd-MM-yyyy):");
		String dt = sc.next();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date date;
		try {
			date = dateFormat.parse(dt);
			sortw w = new sortw(); // Class instance
			w.path(sr, type, date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		sc.close();
	}

}
