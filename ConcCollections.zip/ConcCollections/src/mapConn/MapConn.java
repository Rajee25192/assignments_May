package mapConn;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

class WriterThread<T> extends Thread { // class to write using thread
	private ConcurrentMap<String, List<T>> map;
	private T random;
	private String name;

	public WriterThread(ConcurrentMap<String, List<T>> map2, String threadName, T randomSeed) { // constructor
		this.map = map2;
		this.random = randomSeed;
		this.name = threadName;
	}

	@Override
	public synchronized void run() { // sync threads
		List<T> ls = new ArrayList<>();
		ls.add(random);
		if (!map.containsKey(name)) { // check map
			map.put(name, ls); // add empty
			System.out.println(map.toString());
		} else {
			ls = map.get(name);
			ls.add(random);
			map.put(name, ls); // append value to list
			System.out.println(map.toString());
		}
	}
}

class DeleterThread<T> extends Thread {
	private ConcurrentMap<String, List<T>> map;
	private String name;

	public DeleterThread(ConcurrentMap<String, List<T>> map, String threadName) { // constructor
		this.map = map;
		this.name = threadName;
	}

	@Override
	public synchronized void run() {
		{ // sync threads

			if (map.containsKey(name)) { // check map
				map.remove(name);// remove value
				System.out.println("deleted: " + name);
			} else {
				System.out.println("Not present");
			}
		}
	}
}

public class MapConn {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) {

		ConcurrentHashMap<String, List<String>> map = new ConcurrentHashMap<>(); // concurrent map

		new WriterThread(map, "Writer-1", 1).start();
		new WriterThread(map, "Writer-2", "abc").start();
		new WriterThread(map, "Writer-2", 4).start();

		new DeleterThread(map, "Writer-1").start();
		new DeleterThread(map, "Writer-2").start();
	}

}
