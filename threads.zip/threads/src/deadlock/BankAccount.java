package deadlock;



public class BankAccount {
	double balance;
    int id;
     
    BankAccount(int id, double balance) {
        this.id = id;
        this.balance = balance;
    }
     
    void withdraw(double amount) {
        // Wait to simulate io like database access ...
        try {Thread.sleep(10l);} catch (InterruptedException e) {}
        balance -= amount;
    }
     
    void deposit(double amount) {
        // Wait to simulate io like database access ...
        try {Thread.sleep(10l);} catch (InterruptedException e) {}
        balance += amount;
    }
     
    static void transfer(BankAccount from, BankAccount to, double amount) {
    	/*BankAccount first = null; //setting first to always from(prevents deadlock)
    	BankAccount second = null; //setting second to always to(prevents deadlock)
		
		 * if(from.id == 2) { first = to; second = from; } else { first = from; second =
		 * to; }
		 */
    	
        synchronized(from) {  //replace with first
        	System.out.println("trying to use " + to.id);
        	to.deposit(amount);
            //System.out.println(amount);
            synchronized(to) {  //replace with second
            	
            	from.withdraw(amount);
                
                System.out.println("balance: " +to.balance);
            }
        }
    }
     
	public static void main(String[] args) {
		final BankAccount fooAccount = new BankAccount(1, 100d); //two bankaccount class instances
        final BankAccount barAccount = new BankAccount(2, 100d);
         
        Thread a = new Thread() { //thread a
            public void run() {
            	System.out.println("thread 1");
                BankAccount.transfer(fooAccount, barAccount, 10d);
            }
        };
       
         
        Thread b = new Thread() { //thread b
            public void run() {
            	System.out.println("thread 2");
                BankAccount.transfer(barAccount, fooAccount, 10d);
            }
        };
        
        //two thread start
        a.start();
        b.start();
        // will cause deadlock as a get thread 1, b gets thread 2
        //then a tries to get b, b tries to get a.
        //remove block comments to run without deadlock 

	}

}
