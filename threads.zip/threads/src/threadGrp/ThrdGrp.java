package threadGrp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


class NewThread extends Thread  { 
	File src;
	File des;
	ThreadGroup tgob;
    NewThread(File src, File des, ThreadGroup tgob) //constructor
    { 
       this.src=src;
       this.des=des;
       this.tgob=tgob;
        
    } 
public void run() 
    { 
	  FileInputStream inStream = null; //stream
      FileOutputStream outStream = null;
      
      try
      {
          inStream = new FileInputStream(src);
           
          outStream = new FileOutputStream(des);
           
          byte[] buffer = new byte[1024]; //buffer space
           
          int length;
           
          while ((length = inStream.read(buffer)) != -1) 
          {
              outStream.write(buffer, 0, length); //write to new file
          }
      }
      catch (IOException e)
      {
          e.printStackTrace();
      }
      finally
      {
          try
          {
              inStream.close();
               
              outStream.close();
          }
          catch (IOException e) 
          {
              e.printStackTrace();
          }
      }
      
        System.out.println(Thread.currentThread().getName() +  
            " finished executing"); 
        System.out.println("Finished copying to files........");
    } 
}


class FileThread extends Thread{
	File filePath;
	
	FileThread(File fl, ThreadGroup tg2){
	this.filePath=fl;	
	start(); //start thread
	}
	
	public void run() {
		try {
			
			 Class.forName("com.mysql.cj.jdbc.Driver"); //call jdbc driver
			 System.out.println("Connecting database"); 
		      Connection con = DriverManager.getConnection (
		         "jdbc:mysql://localhost/threadc","root", "kethan"); //create connection to DB
		  
		      String sql = "INSERT INTO lipsom (lipsom) values (?)"; //sql statement
		      PreparedStatement statement = con.prepareStatement(sql);  //prepare statement
		      
		      try(BufferedReader br = new BufferedReader(new FileReader(filePath))) {  // buffered reader
		    	    for(String line; (line = br.readLine()) != null; ) {
		    	    	   statement.setString(1, line); //set variable in sql
		    			      statement.executeUpdate(); //execuet sql
		    			      System.out.println(line);
		    	    }
		    	    // line is not visible here.
		    	}
		      System.out.println("Finished inserting to DB...........");
		   con.close();
		   
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	      
	}
}
public class ThrdGrp {

	public static void main(String[] args) {
		ThreadGroup tg1 = new ThreadGroup("Parent ThreadGroup");  //threadgroup 1
		String filePath = "D:\\eclipse wp\\java1\\threads\\src\\threadGrp\\a.txt"; //ipsom file path
		new NewThread(new File(filePath),new File("D:\\eclipse wp\\java1\\threads\\src\\threadGrp\\b.txt"),tg1).start(); //thread for nw thread class
		new NewThread(new File(filePath),new File("D:\\eclipse wp\\java1\\threads\\src\\threadGrp\\c.txt"),tg1).start();
		
		
		ThreadGroup tg2 = new ThreadGroup("Parent ThreadGroup");  //threadgroup 2
		new FileThread(new File(filePath), tg2); //threads for filethread class
		new FileThread(new File(filePath), tg2);
		
	}

}
