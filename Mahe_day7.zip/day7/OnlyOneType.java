package com.practice.java.day7;

import java.util.ArrayList;
import java.util.List;

//Allow only the first object's type to be stored in the list.
public class OnlyOneType {
	public static void main(String[] args) {

		List<Object> al = new ArrayList<>();

		al.add("Java4s");
		al.add(12.54f);
		al.add(12);
		al.add("J");

		Class<? extends Object> first = al.get(0).getClass();

		for (int i = 0; i < al.size(); i++) {
			Object o = al.get(i);

			if (o.getClass() == first) {
				System.out.println("This object is of the first added element type: " + o.getClass());
			} else {
				System.out.println("Cannot add object of this type." + o.getClass());
				al.remove(i);
				// Decrementing since after removing the element, the next element that needs to
				// be checked gets shifted down to one position.
				i--;
			}
		}

		System.out.println();
		System.out.println("Elements of " + first + " are: ");
		for (int i = 0; i < al.size(); i++) {
			Object o = al.get(i);
			System.out.println(o.toString());
		}

	}
}

class MultipleTypes {
	String str;
	int i;
	boolean bool;

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public boolean isBool() {
		return bool;
	}

	public void setBool(boolean bool) {
		this.bool = bool;
	}
}
