package com.practice.java.day7;

import java.util.ArrayList;
import java.util.List;

public class CircleList {

	public static void main(String[] args) {

		// List of circle objects
		List<Circle> circleObjects = new ArrayList<>();

		while (true) {
			double r = (double) Math.round(Math.random() * 100) / 100;
			double radius = r;

			// If radius is 0.01, we exit the loop.
			if (radius == 0.01) {
				break;
			}

			// Calculating the area of the circle for other random values.
			circleObjects.add(new Circle(radius));
		}

		for (Circle c : circleObjects) {
			System.out.println("Area of a circle with radius " + c.getRadius() + " is " + c.area());
		}
	}
}

class Circle {
	private double radius;

	Circle(double radius) {
		this.radius = radius;
	}

	public double getRadius() {
		return radius;
	}

	public double area() {
		double area = (22 * getRadius() * getRadius()) / 7;
		return (double) Math.round(area * 100) / 100;
	}
}
