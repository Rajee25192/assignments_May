package com.practice.java.day7;

/*
 * The object is created by calling a method that calls a constructor. 
 * Before that, the count is increased for every new object created. 
 * If it is more than 3, the new object is set to  null to stop it from creating a new instance.
 */
public class ThreeObjectsInAClass {
	private static ThreeObjectsInAClass tClass;
	public static int count = 0;

	private ThreeObjectsInAClass() {
		count++;
	}

	public static synchronized ThreeObjectsInAClass getInstance() {
		if (count < 3) {
			tClass = new ThreeObjectsInAClass();
		} else {
			tClass = null;
		}
		return tClass;
	}

	public static void main(String[] args) {
		ThreeObjectsInAClass tClass1 = ThreeObjectsInAClass.getInstance();
		ThreeObjectsInAClass tClass2 = ThreeObjectsInAClass.getInstance();
		ThreeObjectsInAClass tClass3 = ThreeObjectsInAClass.getInstance();
		ThreeObjectsInAClass tClass4 = ThreeObjectsInAClass.getInstance();
		ThreeObjectsInAClass tClass5 = ThreeObjectsInAClass.getInstance();

		System.out.println(tClass1);
		System.out.println(tClass2);
		System.out.println(tClass3);
		System.out.println(tClass4);
		System.out.println(tClass5);

	}
}

//Reference: https://stackoverflow.com/questions/2361863/how-do-i-restrict-object-creation-not-more-than-3-in-java-class
