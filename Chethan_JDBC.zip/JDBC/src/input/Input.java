package input;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Input {

	public static void main(String[] args) {
	
		try {
			String query;
			ResultSet rs;
			 Class.forName("com.mysql.cj.jdbc.Driver");
			 System.out.println("Connecting database");
		      Connection con = DriverManager.getConnection (
		         "jdbc:mysql://localhost/emp","root", "kethan");
		      Statement stmt = con.createStatement();
		      
		      Scanner sc = new Scanner(System.in);
		      System.out.println("Enter name");
		      String name = sc.nextLine();
		      System.out.println("Enter Salary");
		      String salary = sc.nextLine();
		      System.out.println("Enter ID");
		      String id = sc.nextLine();
		      
		      String sql = "INSERT INTO employes " + "(id,Names,salary)" + "VALUES(?,?,?)";
		      PreparedStatement stmt1 = con.prepareStatement(sql);
		      
		      stmt1.setString(1,id);
		      stmt1.setString(2,name);
		      stmt1.setString(3,salary);
		      stmt1.execute();
		  
		      System.out.println("Inserted into table......");
		      System.out.println();
		      query = "select * from employes"; rs = stmt.executeQuery(query);
		      while(rs.next()) {
					 int id1 = rs.getInt("id");
					 String name1 = rs.getString("Names");
					 int salary1 = rs.getInt("salary");
					 
					 System.out.println("id: "+id1);
					 System.out.println("name: "+name1);
					 System.out.println("salary: "+salary1);
					 System.out.println();
				 }
		      rs.close();
		      sc.close();
				stmt.close();
				stmt1.close();
				con.close();
		      
		}
		catch (SQLException se) {
			 se.printStackTrace();
			}
		catch (Exception e) {
				e.printStackTrace();
			}

	}

}
