package tables;

import java.sql.*;

public class Jdbc {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	 static final String DB_URL = "jdbc:mysql://localhost/emp";

	   //  Database credentials
	   static final String USER = "root";
	   static final String PASS = "kethan";
	public static void main(String[] args) {
		 Connection conn = null;
		 Statement stmt = null;
		 
		 try {
			 Class.forName(JDBC_DRIVER); //register driver
			 System.out.println("Connecting database....");
			 conn = DriverManager.getConnection(DB_URL,USER,PASS); //create connection
			 
			 System.out.println("creating Statement...");
			 stmt = conn.createStatement();  //create statement
			 String sql;
			 sql = "select * from employes";
			 ResultSet rs = stmt.executeQuery(sql); //execute query
			 
			 while(rs.next()) { //display all values in the set
				 int id = rs.getInt("id");
				 String name = rs.getString("Names");
				 int salary = rs.getInt("salary");
				 
				 System.out.println("id: "+id);
				 System.out.println("name: "+name);
				 System.out.println("salary: "+salary);
				 System.out.println();
			 }
			 rs.close();
			 stmt.close();
			 conn.close();
			 
		 }
		catch (SQLException se) {
		 se.printStackTrace();
		}
		 catch (Exception e) {
			e.printStackTrace();
		}
		 finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!");
	}
	

}
