package duplicates;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Duplicates {

	public static void main(String[] args) {
		
		try {
			String query;
			ResultSet rs;
			 Class.forName("com.mysql.cj.jdbc.Driver"); //find driver
			 System.out.println("Connecting database");
		      Connection con = DriverManager.getConnection (
		         "jdbc:mysql://localhost/emp","root", "kethan"); //create connection
		      Statement stmt = con.createStatement(); 
		      
		      query = "DELETE t1 FROM employes t1 INNER JOIN employes t2 WHERE t1.id < t2.id AND t1.Names = t2.Names;"; //duplicate removal query
		      String query1 ="Select * from employes"; //select query
		      
		      stmt.executeUpdate(query); //execute duplicate remove query
		      System.out.println("All duplicates with same name removed");
				 rs =  stmt.executeQuery(query1); //Execute select
				 while(rs.next()) { //display all values
					 int id = rs.getInt("id");
					 String name = rs.getString("Names");
					 int salary = rs.getInt("salary");
					 
					 System.out.println("id: "+id);
					 System.out.println("name: "+name);
					 System.out.println("salary: "+salary);
					 System.out.println();
				 }
				 rs.close();
				 stmt.close();
				
		}
		catch (SQLException se) { //catch exception
			 se.printStackTrace();
			}
		catch (Exception e) {
				e.printStackTrace();
			}
	}

}
