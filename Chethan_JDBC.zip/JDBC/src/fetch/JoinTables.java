package fetch;

import java.sql.*;
import java.util.Calendar;

public class JoinTables {

	public static void main(String[] args) {
		try {
			
			String query;
			ResultSet rs;
			 Class.forName("com.mysql.cj.jdbc.Driver"); //get driver
		      Connection con = DriverManager.getConnection (
		         "jdbc:mysql://localhost/emp","root", "kethan"); //create connection
		      Statement stmt = con.createStatement(); //create statement
		     
		      //Join Query
		      query ="SELECT Name,authors.salary from authors join employes on authors.Name = employes.Names AND authors.salary = employes.salary"; 
		      rs = stmt.executeQuery(query); //execute query
		      System.out.println("Name  salary");
		      
		      while (rs.next()) { //display all values in set
		          String name = rs.getString("Name");
		          String salary = rs.getString("salary");
		          System.out.print(name + "  ");
		          System.out.print(salary);
		          System.out.println();
			  
		       }
		      
		      Calendar calendar = Calendar.getInstance(); //get date instance
		      java.sql.Date Date = new java.sql.Date(calendar.getTime().getTime()); //get present date
		      query = "insert into dates(dates)"+ "values(?)";  //query to insert date into date table
		      PreparedStatement stmt1 = con.prepareStatement(query); 
		      stmt1.setDate(1, Date); //set values
		      stmt1.execute(); //execute sql
		      System.out.println("current Date Inserted into table......");
		      System.out.println();
		      query = "select * from dates"; //query for dates
		      rs = stmt.executeQuery(query);
		      System.out.println("Dates table:");
		      
		      while(rs.next()) {//view set
					Date date = rs.getDate("dates"); 
					System.out.println(date);
				 }

		      
		      
		    rs.close();
			stmt.close();
			con.close();

		}
		catch (SQLException se) {
			 se.printStackTrace();
			}
		catch (Exception e) {
				e.printStackTrace();
			}
		
	}

}
